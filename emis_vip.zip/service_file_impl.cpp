#include <fstream>
#include "service_file_impl.h"

using namespace std;

vector<Department> ServiceDaoFileImpl::load(vector<Department> data) //重写读取函数
{
	//cout << "ServiceDaoFileImpl-----1" << endl;
	ServiceDao* s = new ServiceDaoFileImpl;
	fstream load_fs("./data/managers.dat",ios::in); //打开文件
	if(!load_fs.good())
	{
		cout << "file does not exists" << endl;
		return data;
	}
	int did,demp_num; //要读取的部门的编号以及该部门中的员工的数量
	string dname; //要读取的部门名字
	load_fs >> did >> dname >> demp_num;
	//cout << did << " " << dname << " " << demp_num << endl;
	while(!load_fs.eof())
	{
		Department d; //用来接受获取到的部门
		d.setmNid(did);	//设置部门的编号
		d.setmStrName(dname);//设置部门的名字
		vector<Employee> v;
		for(int i=0; i<demp_num-100; i++)
		{
			Employee e;
			int eid,egen_age; //要读取的员工的编号以及员工的年龄
			string ename; //要读取的员工的姓名
			load_fs >> eid >> ename >> egen_age; //读取数据
			//cout << eid << " " << ename << " " << egen_age << endl;
			e.setmNid(eid);//设置员工的编号
			e.setmStrName(ename);//设置员工的姓名
			egen_age >= 100 ? e.setmBGender(1) : e.setmBGender(0);//设置员工的性别
			egen_age >= 100 ? e.setmNAge(egen_age-100) : e.setmNAge(egen_age); //设置员工年龄
			e.setmNDid(d.getmNid());
			v.push_back(e); //插入到部门员工数组当中去
		}
		d.setmVecEmps(v); //设置部门员工
		data.push_back(d); //插入到部门数组当中去
		load_fs >> did >> dname >> demp_num; //继续读取数据
		//cout << did << " " << dname << " " << demp_num << endl;
	}
	load_fs.close();
	return data;
}
void ServiceDaoFileImpl::save(vector<Department>& data) //重写保存函数
{
	//cout<< "~service_file_impl.cpp" << endl;
	fstream save_fs("./data/managers.dat",ios::out); //打开文件
	for(int i=0; i<data.size(); i++) //遍历data部门的数组
	{
		vector<Employee> v = data[i].getmVecEmps(); //获取员工的数组
		save_fs << data[i].getmNid() << " " << data[i].getmStrName() << " " << v.size()+100 << endl; //按照格式写入部门信息
		for(int j=0; j<v.size(); j++) //遍历员工的数组
		{
			save_fs << v[j].getmNid() << " " << v[j].getmStrName() << " " << v[j].getmBGender()*100+v[j].getmNAge() << endl; //按照格式写入员工的信息
		}
	}
	save_fs.close();
}

