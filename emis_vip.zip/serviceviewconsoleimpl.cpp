#include <iostream>
#include "emis.h"
#include "mtools.h"
#include "serviceviewconsoleimpl.h"

using namespace std;


ServiceViewConsoleImpl::ServiceViewConsoleImpl(void)
{
	service = new ServiceImpl;
}
ServiceViewConsoleImpl::~ServiceViewConsoleImpl(void)
{
	delete service;
}

void ServiceViewConsoleImpl::addDept()
{
	mclr_scr();
	cout << "请输入你想要添加的部门名称：";
	Department d;
	string dname;
	cin >> dname;
	getch();
	d.setmNid(deptid++);
	d.setmStrName(dname);
	if(service->addDept(d)) cout << "操作成功" << endl;
	else cout << "操作失败" << endl;
	manykey_continue();
}

void ServiceViewConsoleImpl::deleteDept()
{
	mclr_scr();
	cout << "请输入想要删除的部门编号：";
	int did;
	cin >> did;
	getch();
	if(service->deleteDept(did)) cout << "操作成功" << endl;
	else cout << "操作失败" << endl;
	manykey_continue();
}

void ServiceViewConsoleImpl::listDept()
{
	mclr_scr();
	cout << "listDept()" << endl;
	service->listDept();
	manykey_continue();
}

void ServiceViewConsoleImpl::addEmp()
{
	mclr_scr();
	Employee e;
	int did,age;
	string ename;
	char gender;
	e.setmNid(empid++);
	cout << "请输入想要添加的员工姓名:";
	cin >> ename;
	getch();
	e.setmStrName(ename);
	cout << "请输入想要添加的员工年龄:";
	cin >> age;
	getch();
	e.setmNAge(age);
	cout << "请输入想要添加的员工性别:[b:男/g:女]";
	cin >> gender;
	getch();
	if(gender == 'b') e.setmBGender(true);
	else if(gender == 'g') e.setmBGender(false);
	cout << "请输入该员工的部门编号:";
	cin >> did;
	getch();
	e.setmNDid(did);
	if(service->addEmp(e)) cout << "操作成功" << endl;
	else cout << "操作失败" << endl;
	manykey_continue();
}

void ServiceViewConsoleImpl::deleteEmp()
{
	mclr_scr();
	cout << "请输入要删除的员工编号:";
	int id;
	cin >> id;
	getch();
	if(service->deleteEmp(id)) cout << "操作成功" << endl;
	else cout << "操作失败" << endl;
	manykey_continue();
}

void ServiceViewConsoleImpl::modifyEmp()
{
	mclr_scr();
	cout << "modifyEmp()" << endl;
	Employee e;
	int eid,did,age;
	string ename;
	char gender;
	cout << "请输入想要修改的员工的编号:";
	cin >> eid;
	e.setmNid(eid);
	getch();
	cout << "请输入想要修改的员工姓名:";
	cin >> ename;
	getch();
	e.setmStrName(ename);
	cout << "请输入想要修改的员工年龄:";
	cin >> age;
	getch();
	e.setmNAge(age);
	cout << "请输入想要修改的员工性别:[b:男/g:女]";
	cin >> gender;
	getch();
	if(gender == 'b') e.setmBGender(true);
	else if(gender == 'g') e.setmBGender(false);
	cout << "请输入该员工的部门编号:";
	cin >> did;
	getch();
	e.setmNDid(did);
	if(service->modifyEmp(e)) cout << "操作成功" << endl;
	else cout << "操作失败" << endl;
	manykey_continue();
}

void ServiceViewConsoleImpl::listEmp()
{
	mclr_scr();
	int did;
	cout << "请输入想要打印的部门编号：";
	cin >> did;
	getch();
	service->listEmp(did);
	manykey_continue();
}

void ServiceViewConsoleImpl::listAllEmp()
{
	mclr_scr();;
	service->listAllEmp();
	manykey_continue();
}

void ServiceViewConsoleImpl::menu()
{
	while(true)
	{
		mclr_scr();
		puts("     欢迎进入业务系统");
		puts("        1.添加部门");
		puts("        2.删除部门");
		puts("        3.列出部门");
		puts("        4.添加员工");
		puts("        5.删除员工");
		puts("        6.修改员工");
		puts("        7.列出部门员工");
		puts("        8.列出全部员工");
		puts("        0.退出");            
		char cmd = mget_cmd('0','8');
		switch(cmd)
		{
			case '1': addDept(); break;
			case '2': deleteDept(); break;
			case '3': listDept(); break;
			case '4': addEmp(); break;
			case '5': deleteEmp(); break;
			case '6': modifyEmp(); break;
			case '7': listEmp(); break;
			case '8': listAllEmp(); break;
			case '0': getchar(); return;
		}
	}
}



