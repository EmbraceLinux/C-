#include <iostream>
#include <string.h>
#include "manager.h"

using namespace std;

Manager::Manager(const int id,const char* name,const char* pass)
{
	this->id=id;
	strcpy(this->name,name);
	strcpy(this->password,pass);
}

void Manager::setId(const int id)
{
	this->id=id;
}
int Manager::getId()
{
	return id;
}
void Manager::setName(const char* name)
{
	  strcpy(this->name,name);
}
char* Manager::getName()
{
	  return name;
}
void Manager::setPassWord(const char* pass)
{
	 strcpy(this->password,pass);
}
char* Manager::getPassWord()
{
	  return password;
}
