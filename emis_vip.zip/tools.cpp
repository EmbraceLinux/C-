#include<iostream>
#include<string.h>
#include<stdio.h>
#include<fstream>
#include"tools.h"

using namespace std;

void anony_key(void)
{
    stdin->_IO_read_ptr = stdin->_IO_read_end;
    cout<<"按任意键继续...";
    getchar();
}
//自动生成ＩＤ
int Get_manager_id(void)
{
	ifstream ifd("./data/managerid.dat");
	if(!ifd.is_open())
	{
		ifd.close();
		//不存在则创建
		ofstream ofd("./data/managerid.dat");
		{
			if(!ofd.is_open())
			{
				cout<<"open error"<<endl;
				return -1;
			}
			int initnum=10086;   //初始值
			ofd.write((char*)&initnum,sizeof(int));
			ofd.close();
		}
		return 10086;
	}
	int id;
	ifd.read((char*)&id,sizeof(int));
	id++;
	ifd.close();
	ofstream ofd("./data/managerid.dat");
	{
		if(!ofd)
		{
			cout<<"open error"<<endl;
			return -1;
		}
		ofd.write((char *)&id,sizeof(int));
		ofd.close();
	}
	return id;
}
