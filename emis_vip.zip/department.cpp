#include "department.h"

bool Department::deleteEmp(int id)//根据员工编号删除员工
{
	if(m_vecEmps.empty()) return false; //如果数组为空，则删除失败
	vector<Employee>::iterator it; //使用迭代器来遍历数组，因为earse()的参数为迭代器
	for(it=m_vecEmps.begin(); it!=m_vecEmps.end(); it++)//遍历数组
	{
		//当数组中的employee的id与参数相同的时候
		if((*it).getmNid() == id)
		{
			m_vecEmps.erase(it);//删除员工
			return true;
		}
	}
	return false; //没有该员工，删除失败
}

void Department::listEmp(vector<Employee>& v)//列出本部门的员工，并传入v到中
{
	int size = m_vecEmps.size(); //求出数组的长度方便便利
	if(size == 0) return; //如果数组为空，则直接返回
	for(int i=0; i<size; i++)//便利数组
	{
		Employee e = m_vecEmps[i]; //求出单个数据
		v.push_back(e);//将单个数据添加到v这个数组当中去
	}
}

bool Department::modifyEmp(Employee e)//根据参数，修改本部门的员工
{
	if(m_vecEmps.empty()) return false; //如果数组唯恐为空则返回
	int size = m_vecEmps.size(); //求出数组的长度方便便利
	for(int i=0; i<size; i++)//便利数组
	{
		if(e.getmNid() == m_vecEmps[i].getmNid())//查找符合条件的员工
		{
			m_vecEmps[i] = e;
			return true;
		}
	}
	return false; //查找失败
}

void Department::setmNid(int id)
{
	m_nid = id;
}
void Department::setmStrName(string name)
{
	m_strName = name;
}
void Department::setmVecEmps(vector<Employee> v)
{
	m_vecEmps = v;
}
int Department::getmNid(void)
{
	return m_nid;
}
string Department::getmStrName(void)
{
	return m_strName;
}
vector<Employee>& Department::getmVecEmps(void)
{
	return m_vecEmps;
}
