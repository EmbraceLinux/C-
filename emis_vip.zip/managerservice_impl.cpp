#include <iostream>
#include "managerservice_impl.h"

using namespace std;

vector<Manager> managers;

//--------------------------
ManagerServiceImpl::ManagerServiceImpl()
{
	dao = new ManagerDaoFileImpl;
	managers=dao->load(managers);
}

//--------------------------
ManagerServiceImpl::~ManagerServiceImpl()
{
	delete dao;
}

//--------------------------
bool ManagerServiceImpl::addManager(Manager&manager)
{
	managers.push_back(manager);
	dao->save(managers);
	return true;
}

//--------------------------
bool ManagerServiceImpl::deleteManager(int id)
{
	vector<Manager>::iterator it;
	for(it=managers.begin();it!=managers.end();it++)
	{
		if(it->getId()==id)
		{
			managers.erase(it);
			dao->save(managers);
			return true;
		}
	}
	return false;
}
//--------------------------
vector<Manager>& ManagerServiceImpl::listManager()
{
	return managers;
}
