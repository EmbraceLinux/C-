#include "emis.h"

int deptid;
int empid;
