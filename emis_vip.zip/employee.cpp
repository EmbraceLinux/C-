#include "employee.h"

void Employee::setmNid(int id)
{
	m_nid = id;
}
void Employee::setmStrName(string name)
{
	m_strName = name;
}
void Employee::setmBGender(bool gender)
{
	m_bGender = gender;
}
void Employee::setmNAge(int age)
{
	m_nAge = age;
}
int	Employee::getmNid(void)
{
	return m_nid;
}
string Employee::getmStrName(void)
{
	return m_strName;
}
bool Employee::getmBGender(void)
{
	return m_bGender;
}
int Employee::getmNAge(void)
{
	return m_nAge;
}

int Employee::getmNDid(void)
{
	return m_nDid;
}
void Employee::setmNDid(int did)
{
	m_nDid = did;
}
