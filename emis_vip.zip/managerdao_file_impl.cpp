#include<iostream>
#include<fstream>
#include<vector>
#include "managerdao_file_impl.h"

using namespace std;

ManagerDaoFileImpl::ManagerDaoFileImpl()
{
}
ManagerDaoFileImpl::~ManagerDaoFileImpl()
{
}
vector<Manager>& ManagerDaoFileImpl::load(vector<Manager>& manager)
{
	fstream ifs;
	ifs.open("./data/manager.dat",ios::in|ios::binary);
	if(!ifs.is_open())
	{
		return manager;
	}
	Manager m;
	while(ifs.read((char*)&m,sizeof(Manager)))
	{
		manager.push_back(m);
	}
	return manager;
}
void ManagerDaoFileImpl::save(vector<Manager> &manager)
{
	fstream ofs;
	ofs.open("./data/manager.dat",ios::out|ios::binary);
	if(!ofs.is_open())
	{
		cout<<"open error"<<endl;
		return;
	}
	vector<Manager>::iterator it;
	for(it=manager.begin();it!=manager.end();it++)
	{
		ofs.write((const char*)&*it,sizeof(Manager));
	}
	//cout<<"save success"<<endl;
}

