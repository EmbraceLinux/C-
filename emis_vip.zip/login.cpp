#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <getch.h>
#include "tools.h"
#include "managerservice_impl.h"
#include "managerview_console_impl.h"

using namespace std;

int login(void)
{
	ManagerDaoFileImpl dao;
	vector<Manager> people;
	people = dao.load(people);
	if(!people.size())
	{
		cout<<"------欢迎您首次登陆此系统-----"<<endl;
		cout<<"-------请设置超级管理员!-------"<<endl;
		ManagerViewConsoleImpl m;
		m.add();
		return 0;
	}
	while(1)
	{
		system("clear");
		cout<<" ------指针信息有限公司------ "<<endl;
		cout<<"           welcome            "<<endl<<endl;
		cout<<"       1、管理人员 登陆          "<<endl;
		cout<<"       2、业务经理 登陆          "<<endl;
		cout<<"       3、退    出"<<endl;
		cout<<"------------------------------"<<endl;
		cout<<"请输入选项:";
		int num;
		cin>>num;
		if(num==1)
		{
			vector<Manager>::iterator it;
			int cnt=3;
			char name[20];
			char pass[20];
			while(cnt)
			{
				system("clear");
				cout<<" ------指针信息有限公司------ "<<endl;
				cout<<"           welcome            "<<endl<<endl;
				cout<<endl<<"       用户名：";
				cin>>name;
				getchar();
				cout<<"       密  码：";
				for(int i=0;i<20;i++)
				{
					pass[i]=getch();
					if(pass[i]=='\n')
					{
						pass[i]='\0';
						break;
					}
					cout<<"*";
				}
				cout<<endl<<"------------------------------"<<endl;
				it=people.begin();
				if(strcmp(it->getName(),name)==0 && strcmp(it->getPassWord(),pass)==0)
				{
					cout<<"登陆成功"<<endl;
					anony_key();
					return 0;
				}
				cnt--;
				if(!cnt)
				{
					cout<<"登陆失败三次，请与管理员联系!"<<endl;
					return -1;
				}
				cout<<"帐号或密码错误，重新输入"<<endl;
				anony_key();
			}
		}
		else if(num==2)
		{
			vector<Manager>::iterator it;
			int cnt=3;
			char name[20];
			char pass[20];
			while(cnt)
			{
				system("clear");
				cout<<" ------指针信息有限公司------ "<<endl;
				cout<<"           welcome            "<<endl<<endl;
				cout<<endl<<"       用户名：";
				cin>>name;
				getchar();
				cout<<"       密  码：";
				for(int i=0;i<20;i++)
				{
					pass[i]=getch();
					if(pass[i]=='\n')
					{
						pass[i]='\0';
						break;
					}
					cout<<"*";
				}
				cout<<endl<<"------------------------------"<<endl;
				for(it=++people.begin();it!=people.end();it++)
				{
					if(strcmp(it->getName(),name)==0 && strcmp(it->getPassWord(),pass)==0)
					{
						cout<<"登陆成功"<<endl;
						anony_key();
						return 1;
					}
				}
				cnt--;
				if(!cnt)
				{
					cout<<"登陆失败三次，请与管理员联系!"<<endl;
					return -1;
				}
				cout<<"帐号或密码错误，重新输入"<<endl;
				anony_key();
			}
		}else if(num==3)
		{
			return -1;
		}
		else
		{
			cout<<"输入错误，请重新输入"<<endl;
			anony_key();
			continue;
		}
	}
}
