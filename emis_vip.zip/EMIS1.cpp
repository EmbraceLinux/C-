#include <iostream>
#include "managerview_console_impl.h"
#include "serviceviewconsoleimpl.h"
#include "login.h"
int main()
{
	while(1)
	{
		int choise=login();
		switch(choise)
		{
			case 0:
			{
				ManagerViewConsoleImpl m;
				m.menu();
			}
			break;
			case 1:
			{
				ServiceViewConsoleImpl n;
				n.menu();
			}
			break;
			default:
				return -1;
		}
	}
}
