#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <vector>
#include "tools.h"
#include "manager.h"
#include "managerservice_impl.h"
#include "managerview_console_impl.h"

using namespace std;

//--------------------------
//构造函数
ManagerViewConsoleImpl::ManagerViewConsoleImpl()
{
	  service = new ManagerServiceImpl;
}
//--------------------------
//添加
void ManagerViewConsoleImpl::add(void)
{
	cout<<"设置超级管理员"<<endl;
	Manager m;
	int id=0;
	char name[20];
	char pass[20];
	cout<<"请输入姓名:";
	cin>>name;
	cout<<"请输入密码:";
	cin>>pass;
	id = Get_manager_id();
	m.setId(id);
	m.setName(name);
	m.setPassWord(pass);
	if(service->addManager(m))
	{
		cout<<"save成功"<<endl;
	}
	else
	{
		cout<<"save失败"<<endl;
	}
}
//--------------------------
//删除
void ManagerViewConsoleImpl::del(void)
{
	int id;
	cout<<"请输入ＩＤ删除：";
	cin>>id;
	if(service->deleteManager(id))
	{
		cout<<"delete成功"<<endl;
	}
	else
	{
		cout<<"delete失败"<<endl;
	}
}
//--------------------------
//显示
void ManagerViewConsoleImpl::list(void)
{
	vector<Manager> managers;
	managers=service->listManager();
	vector<Manager>::iterator it;
	for(it=managers.begin();it!=managers.end();it++)
	{
		cout<<it->getId()<<" ";
		cout<<it->getName()<<" "<<endl;;
	}
}
//--------------------------
//菜单
void ManagerViewConsoleImpl::menu(void)
{
	while(true)
	{
		system("clear");
		cout<<"---指针公司信息管理系统---"<<endl;
		cout<<"    1、添加管理员"<<endl;
		cout<<"    2、删除管理员"<<endl;
		cout<<"    3、显示管理员"<<endl;
		cout<<"    4、返      回"<<endl;
		int num=0;
		cout<<"请输入选项";
	    cin>>num;
	    switch(num)
	    {
	        case 1: add();
	                anony_key(); break;
	        case 2: del();
	                anony_key(); break;
	        case 3: list();
	                anony_key(); break;
	        case 4: return;
	        default:
	            cout<<"选项错误，请重新输入"<<endl; break;
    	}
	}
}
