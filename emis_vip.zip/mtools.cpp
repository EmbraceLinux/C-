#include <iostream>
#include <fstream>
#include <cstdlib>
#include "mtools.h"
#include "emis.h"
using namespace std;

char mget_cmd(char begin,char end)//获取命令
{
	char cmd;
	if(begin > end) return -1;
	cout << "请输入指令:";
	while(true)
	{
		cmd = getch();
		if(cmd >= begin && cmd <= end)
		{
			cout << cmd << endl;
			return cmd;
		}
	} 
	
}

void mclr_scr(void)//清空屏幕
{
	system("clear");
}

void manykey_continue(void)//任意键返回
{
	cout << "按任意键返回...";
	getch();
	cout << endl;
}

void load_id()
{
	fstream fs("./data/mid.dat",ios::in);
	if(!fs.good()) cout << "file does not exist" << endl;
	fs >> deptid >> empid;
	cout << deptid << " " << empid << endl;
}

void save_id()
{
	fstream fs("./data/mid.dat",ios::out);
	if(!fs.good()) cout << "file does not exist" << endl;
	fs << deptid << " " << empid << endl;
}
