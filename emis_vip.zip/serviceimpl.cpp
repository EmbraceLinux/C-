#include "ServiceImpl.h"

ServiceImpl::ServiceImpl(void)
{
	//cout << "ServiceImpl" << endl;
	servicedao = new ServiceDaoFileImpl;
	deptVec = servicedao->load(deptVec);
	//cout << deptVec[1].getmNid() << endl;
}

ServiceImpl::~ServiceImpl(void)
{
	//cout << "~service_impl.cpp" << endl;
	servicedao->save(deptVec);
	delete servicedao;
}

ServiceDao* ServiceImpl::getServiceDao(void)
{
	return servicedao;
}

void ServiceImpl::setServiceDao(ServiceDaoFileImpl* s)
{
	servicedao = s;
}

vector<Department> ServiceImpl::getDeptVec(void)
{
	return deptVec;
}

void ServiceImpl::setDeptVec(vector<Department> v)
{
	v = deptVec;
}


bool ServiceImpl::addDept(Department dept)
{
	deptVec.push_back(dept);
	return true;
}

 bool ServiceImpl::deleteDept(int Deptid)
{
	if(deptVec.size() == 0) return false; //如果数组为空则返回失败
	vector<Department>::iterator it; //用earse()来删除数组
	for(it=deptVec.begin(); it!=deptVec.end(); it++)//遍历数组
	{
		if((*it).getmNid() == Deptid) //找到条件符合的删除元素
		{
			deptVec.erase(it);
			return true;
		}
	}
	return false; //找不到则返回失败
}

void ServiceImpl::listDept(void)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		vector<Employee> e = deptVec[i].getmVecEmps();
		cout << deptVec[i].getmNid() << " " << deptVec[i].getmStrName() << endl;
	}
}

bool ServiceImpl::addEmp(Employee emp)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		if(deptVec[i].getmNid() == emp.getmNDid())
		{
			vector<Employee> e = deptVec[i].getmVecEmps();
			e.push_back(emp);
			deptVec[i].setmVecEmps(e);
			return true;
		}
	}
	return false;
}

bool ServiceImpl::deleteEmp(int Empid)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		if(deptVec[i].deleteEmp(Empid)) return true;
	}
	return false;
}

bool ServiceImpl::modifyEmp(Employee emp)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		vector<Employee> e = deptVec[i].getmVecEmps();
		for(int j=0; j<e.size(); j++)
		{
			if(emp.getmNid() == e[j].getmNid())
			{
				if(emp.getmNDid() != e[j].getmNDid())
				{
					deptVec[i].deleteEmp(e[j].getmNid());
					addEmp(emp);
					return true;
				}
				else
				{
					e[j] = emp;
					deptVec[i].setmVecEmps(e);
					return true;
				}
			}
		}
	}
	return false;
}

void ServiceImpl::listEmp(int Deptid)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		if(deptVec[i].getmNid() == Deptid)
		{
			vector<Employee> e = deptVec[i].getmVecEmps();
			for(int j=0; j<e.size(); j++)
			{
				cout << e[j].getmNid() << " " << e[j].getmStrName() << " " << (e[j].getmBGender() ? "男" : "女" ) << e[j].getmNAge() << " " << e[j].getmNDid() << endl;
			}
		}
	}
}

void ServiceImpl::listAllEmp(void)
{
	for(int i=0; i<deptVec.size(); i++)
	{
		vector<Employee> e = deptVec[i].getmVecEmps();
		for(int j=0; j<e.size(); j++)
		{
			cout << e[j].getmNid() << " " << e[j].getmStrName() << " " << (e[j].getmBGender() ? "男" : "女" ) << e[j].getmNAge() << " " << e[j].getmNDid() << endl;
		}
	}
}











