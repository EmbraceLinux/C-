#ifndef SERVICEVIEWCONSOLEIMPL
#define SERVICEVIEWCONSOLEIMPL

#include "serviceview.h"
#include "service.h"
#include "ServiceImpl.h"
#include "department.h"
#include "employee.h"

class ServiceViewConsoleImpl:public ServiceView
{
private:
	Service* service;
public:
	ServiceViewConsoleImpl(void);
	~ServiceViewConsoleImpl(void);
	void menu();
	void addDept();
	void deleteDept();
	void listDept();
	void addEmp();
	void deleteEmp();
	void modifyEmp();
	void listEmp();
	void listAllEmp();
};

#endif //SERVICEVIEWCONSOLEIMPL
