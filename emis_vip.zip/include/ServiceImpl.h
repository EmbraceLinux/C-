#ifndef SERVICEIMPL_H
#define SERVICEIMPL_H

#include "service.h"
#include "servicedao.h"
#include "service_file_impl.h"

class ServiceImpl:public Service
{
private:
	ServiceDao* servicedao;
	vector<Department> deptVec;
public:
	ServiceImpl(void);
	~ServiceImpl(void);
	ServiceDao* getServiceDao(void);
	void setServiceDao(ServiceDaoFileImpl* s);
	vector<Department> getDeptVec(void);
	void setDeptVec(vector<Department> v);
	bool addDept(Department dept);		//重写添加部门的函数
	bool deleteDept(int Deptid);		//重写删除部门的函数
	void listDept(void);				//重写列出部门的函数
	bool addEmp(Employee emp);			//重写添加员工的函数
	bool deleteEmp(int Empid);			//重写删除员工的函数
	bool modifyEmp(Employee emp);			//重写修改员工的函数
	void listEmp(int Deptid);			//重写列出该部门的所有员工的函数
	void listAllEmp(void);				//重写列出所有员工的函数
};

#endif //SERVICEIMPL_H
