#include<iostream>


void anony_key(void);

int Get_manager_id(void);
