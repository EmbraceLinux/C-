#ifndef TOOLS_H
#define TOOLS_H

#include<getch.h>

char mget_cmd(char begin,char end);

void mclr_scr(void);

void manykey_continue(void);

void load_id();

void save_id();

#endif //TOOLS_H
