#ifndef MANAGER_H
#define MANAGER_H

class Manager
{
	int id;
	char name[20];
	char password[20];
public:
	Manager(const int id=0,const char *name="",const char *pass="");
	~Manager(){}
	void setId(const int id);
	int  getId();
	void  setName(const char *name);
	char* getName();
	void  setPassWord(const char*pass);
	char *getPassWord();
};

#endif //MANAGER_H
