#ifndef LOGIN_H
#define LOGIN_H

int login(void);
#endif //LOGIN_H
