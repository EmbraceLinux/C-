#ifndef MANAGERSERVICE_H
#define MANAGERSERVICE_H

#include <vector>
#include "manager.h"

using namespace std;

class ManagerService
{

public:
	virtual ~ManagerService(){}
	virtual bool addManager(Manager& manager)=0;
	virtual bool deleteManager(int id)=0;
	virtual vector<Manager> &listManager()=0;
};

#endif// MANAGERSERVICE_H
