#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
using namespace std;

class Employee
{
	int		m_nid;		//ID
	string	m_strName;	//姓名
	bool	m_bGender;	//性别
	int 	m_nAge;		//年龄 
	int		m_nDid;		//部门ID
public:
	void setmNid(int id);           
	void setmStrName(string name);
	void setmBGender(bool gender);
	void setmNAge(int age);
	int	getmNid(void);
	string getmStrName(void);
	bool getmBGender(void);
	int getmNAge(void);
	int getmNDid(void);
	void setmNDid(int did);
};

#endif //EMPLOYEE_H
