#ifndef SERVICE_H
#define SERVICE_H

#include "department.h"

class Service
{
public:
	virtual ~Service(void) {}
	virtual bool addDept(Department dept)=0;	//新增部门
	virtual bool deleteDept(int Deptid)=0;		//删除部门
	virtual void listDept(void)=0; 				//列出部门
	virtual bool addEmp(Employee emp)=0;		//新增员工
	virtual bool deleteEmp(int Empid)=0;		//删除员工
	virtual bool modifyEmp(Employee emp)=0;			//修改员工
	virtual void listEmp(int Deptid)=0;			//列出员工
	virtual void listAllEmp(void)=0;			//列出所有员工
};
#endif //SERVICE_H

