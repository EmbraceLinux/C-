#ifndef SERVICE_FILE_IMPL_H
#define SERVICE_FILE_IMPL_H

#include "servicedao.h"


class ServiceDaoFileImpl:public ServiceDao
{
public:
	vector<Department> load(vector<Department> data); //重写读取函数
	void save(vector<Department>& data); //重写保存函数
};

#endif //SERVICE_FILE_IMPL_H
