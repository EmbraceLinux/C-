#ifndef MANAGER_DAO_FILE_IMPL_H
#define MANAGER_DAO_FILE_IMPL_H

#include <vector>
#include "manager.h"
#include "managerdao.h"

using namespace std;

class ManagerDaoFileImpl:public ManagerDao
{
public:
	ManagerDaoFileImpl();
	~ManagerDaoFileImpl();
	vector<Manager>& load(vector<Manager>& manager);
	void save(vector<Manager>& manager);
};

#endif// MANAGER_DAO_FILE_IMPL_H
