#ifndef DEPARTMENT_H
#define DEPARTMENT_H

#include <vector>
#include "employee.h"


class Department
{
	int 				m_nid; 		//部门编号
	string				m_strName;	//部门名称
	vector<Employee>	m_vecEmps;	//员工对象容器
public:
	bool deleteEmp(int id);				//根据员工编号删除员工
	void listEmp(vector<Employee>& v);	//列出本部门的员工，并传入v到中
	bool modifyEmp(Employee e);			//根据参数，修改本部门的员工
	void setmNid(int id);
	void setmStrName(string name);
	void setmVecEmps(vector<Employee> v);
	int getmNid(void);
	string getmStrName(void);
	vector<Employee>& getmVecEmps(void);
};

#endif //DEPARTMENT_H
