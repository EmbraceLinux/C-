#ifndef MANAGERSERVICE_IMPL_H
#define MANAGERSERVICE_IMPL_H

#include <vector>
#include "managerservice.h"
#include "managerdao_file_impl.h"
#include "manager.h"

class ManagerServiceImpl:public ManagerService
{
	vector<Manager> managers;
	ManagerDaoFileImpl* dao;
public:
	ManagerServiceImpl();
	~ManagerServiceImpl();
	bool addManager(Manager& manager);
	bool deleteManager(int id);
	vector<Manager>& listManager();
};

#endif// MANAGERSERVICE_IMPL_H
