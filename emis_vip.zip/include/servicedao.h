#ifndef SERVICEDAO_H
#define SERVICEDAO_H

#include "department.h"

class ServiceDao
{
public:
	virtual vector<Department> load(vector<Department> data)=0;	//读取数据
	virtual void save(vector<Department>& data)=0; 	//保存数据
};

#endif //SERVICEDAO_H
