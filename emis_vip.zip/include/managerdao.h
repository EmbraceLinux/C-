#ifndef MANAGERDAO_H
#define MANAGERDAO_H

#include <vector>
#include "manager.h"
using namespace std;

class ManagerDao
{
public:
	virtual ~ManagerDao(){}
	virtual vector<Manager>& load(vector<Manager>& managers)=0;
	virtual void save(vector<Manager>& manager)=0;
};

#endif//MANAGERDAO_H
