#ifndef EMIS_H
#define EMIS_H

extern int deptid;
extern int empid;
#endif //EMIS_H
