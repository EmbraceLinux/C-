#ifndef SERVICEVIEW_H
#define SERVICEVIEW_H

class ServiceView
{
public:
	virtual ~ServiceView(void) {}
	virtual void menu()=0;			//菜单界面
	virtual void addDept()=0;		//添加部门界面
	virtual void deleteDept()=0;	//删除部门界面
	virtual void listDept()=0;		//列出部门界面
	virtual void addEmp()=0;		//添加员工界面
	virtual void deleteEmp()=0;		//删除员工界面
	virtual void modifyEmp()=0;		//修改员工界面
	virtual void listEmp()=0;		//列出所有部门员工界面
	virtual void listAllEmp()=0;	//列出所有员工界面
};
#endif //SERVICEVIEW_H
