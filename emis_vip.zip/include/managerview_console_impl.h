#ifndef MANAGERVIEW_CONSOLE_IMPL_H
#define MANAGERVIEW_CONSOLE_IMPL_H

#include <iostream>
#include "managerview.h"
#include "managerservice_impl.h"

class ManagerViewConsoleImpl:public ManagerView
{
	ManagerServiceImpl *service;

public:
	ManagerViewConsoleImpl();
	~ManagerViewConsoleImpl(void)
	{
		delete service;
	}
	void menu(void);
	
	void add(void);
	
	void del(void);
	
	void list(void);
};

#endif// MANAGERVIEW_CONSOLE_IMPL_H
